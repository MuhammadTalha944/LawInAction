@extends('layouts.website.app')
@section('title', 'Hate Form Status')
@section('content')


<div class="jumbotron text-center" style="padding: 2% !important;">
  <h2>Public Hate Form Status</h2>
</div>
  
<div class="container" style="margin-bottom: 2%;">

  <div class="row" style="margin-top: 2%;">
    @if(count($hf) > 0 )
          @foreach($hf as $hform)
            <div class="col-sm-6 offset-sm-3">
              <div class="card" style="box-shadow: 4px 7px #e1dede;">
                <div class="card-body">
                    <h3>Hate Form # <small>{{ $hform->hateform_number}}</small></h3>
                    <p><b>Complaint added By :</b> {{$hform->name}}
                      <br>
                    </p>
                    <p><b>Country : </b> {{$hform->country}}</p>

                    <div style="text-align: right;">
                       <button type="button" class="btn btn-sm btn-primary">Status : <b>{{$hform->status->name}}</b></button> 
                       <a href="{{route('hateForm.detail', $hform->hateform_number )}}" class="btn btn-sm btn-warning">Open Hate Form Details</a>
                    </div>
                </div>
              </div>
            </div>
            @endforeach
        @else
        <div class="col-sm-12">
              <div class="card" style="box-shadow: 4px 7px #e1dede;text-align: center;">
                <h3>No Hate Form Found, Search Again !!</h3>
              </div>
          </div>
        @endif
  </div>


</div>

@endsection