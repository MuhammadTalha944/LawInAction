@extends('layouts.website.app')
@section('title', 'Hate Form')
@section('content')

  <style type="text/css">
      .background_gradient{
        /*background: linear-gradient(170deg, rgba(76,78,86,1) 21%, rgba(255,204,25,0.964005585144214) 44%, rgba(0,0,0,1) 85%);*/
        /*background: linear-gradient(170deg, rgba(76,78,86,1) 32%, rgba(255,204,25,0.964005585144214) 72%); */
        /*background: linear-gradient(170deg, rgba(255,204,25,1) 32%, rgba(255,204,25,0.964005585144214) 72%); */
      
        /*background: linear-gradient(170deg, rgba(0,0,0,1) 32%, rgba(255,204,25,0.964005585144214) 72%);*/
        background: linear-gradient(170deg, rgb(179, 168, 168) 32%, rgba(200, 179, 106, 0.96) 72%);
      }
  </style>

  <div class="jumbotron text-center">
    <h2>Public Hate-Forms</h2>
  </div>
  
<div class="container" style="margin-bottom: 2%;">
    <div class="row" style="margin-top: 2%;">
        @if(count($hate_form) > 0)
          @foreach($hate_form as $hf)
                <div class="col-sm-4" style="margin-bottom: 1%;">
                  <div class="card" style="box-shadow: 4px 7px #e1dede; border-radius: 5%; background: linear-gradient(170deg, rgb(179, 168, 168) 32%, rgba(200, 179, 106, 0.96) 72%);">
                    <div class="card-body background_gradient" style="border-radius: 5%;">
                        <h4 style="color: white;">Hate Form # {{ ++$loop->index }}</h4>
                        <p style="color: white;">Hate Form added By : <b>{{$hf->name}}</b>
                          <br>
                          From Country : <b>{{ $hf->country }}</b></p>
                        <div style="text-align: right;">
                           
                           <button type="button" class="btn btn-sm 
                                              @if($hf->status->name == 'Initiated')
                                                  btn-primary
                                              @elseif($hf->status->name == 'Open')
                                                  btn-primary
                                              @elseif($hf->status->name == 'Under Proceesing')
                                                  btn-success
                                              @elseif($hf->status->name == 'Pending')
                                                  btn-danger
                                              @elseif($hf->status->name == 'Resolved')
                                                  btn-success
                                              @elseif($hf->status->name == 'Closed')
                                                  btn-warning
                                              @endif  ">{{$hf->status->name}}</button>

                           <a href="{{route('hateForm.detail', $hf->hateform_number )}}" class="btn btn-sm btn-warning">Open <i class="fas fa-external-link-alt"></i></a>
                        </div>
                    </div>
                  </div>
                </div>
          @endforeach
          @else
            <div class="card" style="box-shadow: 4px 7px #e1dede;">
              <div class="card-body " style="text-align: center;">
                  <h3>No Hate  Forms Found</h3>
              </div>
            </div>
          @endif
    </div>
</div>
@endsection