<!DOCTYPE html>
<html>
<head>
    <title>Lawyers In Action</title>
</head>
<body>    
<h3>Hello, {{ $details['name'] }}<br></h3> 
<div>{{ $details['body'] }}  </div>
<div>
    <p>Website : {{ $details['link'] }}</p>
</div>
<br>
Thank you
</body>
</html>