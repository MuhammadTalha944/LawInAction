@extends('layouts.dashboard.main')
@section('title','80G certificate')
@section('content')

 <div class="card yellow_border shadow h-100 py-2">
    <div class="card-body">
            <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h4>80G taxtation Certificate</h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                
            </div>


        </div>
    </div>
</div>

@endsection