@extends('layouts.website.app')
@section('title', 'Complaint Details')
@section('content')

  <style type="text/css">
        .card-white  .card-heading {
          color: #333;
          background-color: #fff;
          border-color: #ddd;
           border: 1px solid #dddddd;
        }
        .card-white  .card-footer {
          background-color: #fff;
          border-color: #ddd;
        }
        .card-white .h5 {
            font-size:14px;
            //font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
        }
        .card-white .time {
            font-size:12px;
            //font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
        }
        .post .post-heading {
          height: 95px;
          padding: 20px 15px;
        }
        .post .post-heading .avatar {
          width: 60px;
          height: 60px;
          display: block;
          margin-right: 15px;
        }
        .post .post-heading .meta .title {
          margin-bottom: 0;
        }
        .post .post-heading .meta .title a {
          color: black;
        }
        .post .post-heading .meta .title a:hover {
          color: #aaaaaa;
        }
        .post .post-heading .meta .time {
          margin-top: 8px;
          color: #999;
        }
        .post .post-image .image {
          width: 100%;
          height: auto;
        }
        .post .post-description {
          padding: 15px;
        }
        .post .post-description p {
          font-size: 14px;
        }
        .post .post-description .stats {
          margin-top: 20px;
        }
        .post .post-description .stats .stat-item {
          display: inline-block;
          margin-right: 15px;
        }
        .post .post-description .stats .stat-item .icon {
          margin-right: 8px;
        }
        .post .post-footer {
          border-top: 1px solid #ddd;
          padding: 15px;
        }
        .post .post-footer .input-group-addon a {
          color: #454545;
        }
        .post .post-footer .comments-list {
          padding: 0;
          margin-top: 20px;
          list-style-type: none;
        }
        .post .post-footer .comments-list .comment {
          display: block;
          width: 100%;
          margin: 20px 0;
        }
        .post .post-footer .comments-list .comment .avatar {
          width: 35px;
          height: 35px;
        }
        .post .post-footer .comments-list .comment .comment-heading {
          display: block;
          width: 100%;
        }
        .post .post-footer .comments-list .comment .comment-heading .user {
          font-size: 14px;
          font-weight: bold;
          display: inline;
          margin-top: 0;
          margin-right: 10px;
        }
        .post .post-footer .comments-list .comment .comment-heading .time {
          font-size: 12px;
          color: #aaa;
          margin-top: 0;
          display: inline;
        }
        .post .post-footer .comments-list .comment .comment-body {
          margin-left: 50px;
        }
        .post .post-footer .comments-list .comment > .comments-list {
          margin-left: 50px;
        }
       label{
          font-weight: 700;
      }


        .content-item {
            /*padding:30px 0;*/
          background-color:#FFFFFF;
        }

        .content-item.grey {
          background-color:#F0F0F0;
          padding:50px 0;
          height:100%;
        }

        .content-item h2 {
          font-weight:700;
          font-size:35px;
          line-height:45px;
          text-transform:uppercase;
          margin:20px 0;
        }

        .content-item h3 {
          font-weight:400;
          font-size:20px;
          color:#555555;
          margin:10px 0 15px;
          padding:0;
        }

        .content-headline {
          height:1px;
          text-align:center;
          margin:20px 0 70px;
        }

        .content-headline h2 {
          background-color:#FFFFFF;
          display:inline-block;
          margin:-20px auto 0;
          padding:0 20px;
        }

        .grey .content-headline h2 {
          background-color:#F0F0F0;
        }

        .content-headline h3 {
          font-size:14px;
          color:#AAAAAA;
          display:block;
        }


        #comments {
            /*box-shadow: 0 -1px 6px 1px rgba(0,0,0,0.1);*/
          background-color:#FFFFFF;
        }

        #comments form {
          margin-bottom:30px;
        }

        #comments .btn {
          margin-top:7px;
        }

        #comments form fieldset {
          clear:both;
        }

        #comments form textarea {
          height:100px;
        }

        #comments .media {
          border-top:1px dashed #DDDDDD;
          /*padding:20px 0;*/
          margin:0;
        }

        #comments .media > .pull-left {
            margin-right:20px;
        }

        #comments .media img {
          max-width:100px;
        }

        #comments .media h4 {
          margin:0 0 10px;
        }

        #comments .media h4 span {
          font-size:14px;
          float:right;
          color:#999999;
        }

        #comments .media p {
          margin-bottom:15px;
          text-align:justify;
        }

        #comments .media-detail {
          margin:0;
        }

        #comments .media-detail li {
          color:#AAAAAA;
          font-size:12px;
          padding-right: 10px;
          font-weight:600;
        }

        #comments .media-detail a:hover {
          text-decoration:underline;
        }

        #comments .media-detail li:last-child {
          padding-right:0;
        }

        #comments .media-detail li i {
          color:#666666;
          font-size:15px;
          margin-right:10px;
        }
        .media-heading{
            font-size: 80%;
        }
      /*  .p_comment{
          padding: 1%;
          border: 1px solid lightgray;
          border-radius: 8%;
        }*/
  </style>

  <div class="jumbotron text-center" style="padding: 2% !important;">
    <h2>Public Complaints Detail</h2>
  </div>
  
  <div class="container" style="margin-bottom: 2%;">

    <div class="row" style="margin-top: 2%;">
          <div class="col-12">
            <h5>Complaint # {{$complaint['complaint_number']}}</h5>
              <div class="card card-white post">
                  <div class="post-heading">
                      <div class="float-left image">
                          <img src="{{   asset('storage/complaints/photo/'.$complaint['photo'])  }}" 
                                    class="img-circle avatar" alt="Complainent profile image">
                      </div>
                      <div class="float-left meta">
                          <div class="title h5">
                              <a href="#"><b>{{$complaint['name'] }}</b></a>
                              filed a complaint.
                          </div>
                          @php
                                $timestamp = strtotime($complaint['created_at']);
                                $date = date('M D Y', $timestamp);
                                $time = date('H:i a', $timestamp);
                          @endphp
                          <h6 class="text-muted time">On {{$date }} at {{$time}}</h6>
                      </div>
                  </div> 
                  <div class="post-description"> 
                    <h4><b><u>Lodged Grievance:</u></b></h4>
                     @if(file_exists(public_path('storage/complaints/grievance/'.$complaint['grievance'])))
                          <a href="{{asset('storage/complaints/grievance/'.$complaint['grievance'])}}" target="_blank">
                                Open Grievance File</a>
                      @else
                       <p>
                          {{$complaint['grievance']}}
                       </p>
                       @endif
                       <div style="text-align: right;">
                           <a class="btn btn-yellow btn-sm" data-toggle="collapse" href="#collapseComplaintDetails" role="button" aria-expanded="false" aria-controls="collapseComplaintDetails">
                            More Detail <i class="fas fa-arrow-circle-down"></i>
                          </a>
                       </div>
                      <div class="collapse" id="collapseComplaintDetails">
                        <div class="card card-body">
                                          <div class="form-group row">
                                            <div class="col-md-6 mb-3 mb-sm-0">
                                                <label>Age:</label>
                                                 <p>{{$complaint['age']}}</p>
                                            </div>
                                            <div class="col-md-6 mb-3 mb-sm-0">
                                                <label>Phone number :</label>
                                                 <p>+91{{$complaint['phone_number']}}</p>
                                            </div>
                                        </div>
                                        <div class="form-group  row">
                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                <label>Email:</label>
                                                 <p>{{$complaint['email']}}</p>
                                            </div>
                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                <label>Country:</label>
                                                 <p>{{$complaint['country']}}</p>
                                            </div>
                                        </div>
                                        @if($complaint['country'] == 'India')
                                        <div class="form-group row country_dependent" style=""> 
                                        
                                            <div class="col-sm-6 " >
                                                        <label>State:</label>
                                                             <p>{{$complaint['state']['name']}}</p>
                                            </div>
                                            <div class="col-sm-6 country_dependent" >
                                                <label>District:</label>
                                                    <p>{{$complaint['district']['name']}}</p>
                                            </div>
                                        </div>  
                                        
                                        <div class="form-group row country_dependent"  id="" >
                                                                        <div class="col-sm-6 mb-3 mb-sm-0">
                                                                            <label>Police Station:</label>
                                                                                <p>{{$complaint['police_station']}}</p>
                                                                        </div>
                                                                        <div class="col-sm-6">
                                                                            <label>Pin Code:</label>
                                                                                <p>{{$complaint['pin_code']}}</p>

                                                                        </div>
                                                                        <div class="col-sm-12">
                                                                            <label>Correspondence Address:</label>
                                                                                <p>{{$complaint['correspondence_address']}}</p>
                                                                           
                                                                        </div>
                                        </div>
                                        @endif
                                        <div class="form-group row">
                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                <label>Complaint Category:</label>
                                                    <p>
                                                      @if($complaint['complaint_related_to'] == 'Communal_Riots')
                                                              Communal Riots
                                                      @elseif($complaint['complaint_related_to'] == 'Tablighi_Jamaat')
                                                              Tablighi Jamaat
                                                      @elseif($complaint['complaint_related_to'] == 'Corona_Related')
                                                              Corona Related
                                                      @elseif($complaint['complaint_related_to'] == 'Personal_Matter')
                                                              Personal Matter
                                                      @elseif($complaint['complaint_related_to'] == 'Mob_Lynching')
                                                              Mob Lynching
                                                      @elseif($complaint['complaint_related_to'] == 'Religious_Caste_Discrimination')
                                                              Religious Caste Discrimination
                                                      @elseif($complaint['complaint_related_to'] == 'Other_Issues')
                                                              Other Issues
                                                      @elseif($complaint['complaint_related_to'] == 'Other_Hate_Crimes')
                                                              Other Hate Crimes
                                                      @endif
                                                      {{$complaint['complaint_related_to']}}
                                                    </p>

                                            </div>
                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                <label>Are you:</label>
                                                    <p>{{$complaint['vistim_accused']}}</p>
                                                
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                <label>Fir Copy:</label>
                                               @if($complaint['fir_copy'] == null)
                                                    No Fir File
                                                @else
                                                        @php 
                                                            $path = storage_path('complaints/fir/' . $complaint['fir_copy']);
                                                        @endphp
                                                    <a href="{{asset('storage/complaints/fir/'.$complaint['fir_copy'])}}" target="_blank">
                                                    Open FIR Copy in next tab</a>
                                                @endif
                                            </div>
                                        </div>
                                
                                        {{-- <div class="row " >
                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                <label>Your ID for Proof:</label>
                                                     <a href="{{asset('storage/complaints/id_proof/'.$complaint['id_proof'])}}" target="_blank">
                                                          Open ID Proof</a>
                                            </div>
                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                <label>Clear face photograpgh:</label>
                                            
                                                <a href="{{asset('storage/complaints/photo/'.$complaint['photo'])}}" target="_blank">
                                                          Open Image</a>
                                            </div>
                                        </div> --}}
                                        <div class="row ">
                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                <label>Adress for Proof:</label>
                                                <p>
                                                    {{$complaint['address_proof']}}
                                                </p>
                                            </div>
                                            <div class="col-sm-6 mb-3 mb-sm-0">
                                                 <label>Complaint Confidentiality:</label>
                                                <button type="button" class="btn btn-sm btn-success">{{$complaint['confidentiality']}}</button>
                                            </div>
                                        </div> 

                                        </div>
                      </div>
                      <hr>
                        <section class="content-item" id="comments">
                            <div class="container">   
                              <div class="row">
                                    <div class="col-sm-8">   
                                       <div style="text-align: left;">
                                           <a class="" data-toggle="collapse" href="#collapseComplaintComments" role="button" aria-expanded="false" aria-controls="collapseComplaintComments">
                                              <h3 class="pull-left" style="background-color: #e1e1e1;">Write your Comment...!</h3>
                                          </a>
                                     </div>
                                     <div class="collapse" id="collapseComplaintComments">
                                        <form >
                                            <fieldset>
                                                <div class="row">
                                                      <div class="col-sm-12 col-lg-10 hidden-xs" style="margin-bottom: 2%;">
                                                        <input type="email" id="email" name="user_email" required class="form-control" placeholder="Enter your Email">
                                                    </div>
                                                    <div class="form-group col-xs-12 col-sm-9 col-lg-10">
                                                        {{-- <input type="text" name="complaint_comment" required class="form-control" placeholder="Write your Comment here...!"> --}}
                                                        <textarea class="form-control" required id="complaint_comment" name="complaint_comment"></textarea>
                                                    </div>
                                                    <div class="col-sm-10 col-lg-19 hidden-xs" style="text-align: right;"> 
                                                      <input type="hidden" name="complaint_id"  id="complaint_id" value="{{$complaint['id']}}">
                                                          <button type="button" class="btn btn-success btn-sm  pull-right" id="btn-save">Submit</button>
                                                        {{-- <input type="submit" name="user_email" value="submit" class="form-control"> --}}
                                                    </div>
                                                </div>    
                                            </fieldset>
                                        </form>
                                      </div>

                                      <div id="comment_Added" style="display: none; background-color: lightgreen; padding: 1%;">
                                        <span><b>Your comment is added on this complaint!</b></span>
                                      </div>
                                        
                                        <h3>All Comments</h3>
                                        
                                        <!-- COMMENT  - START -->
                                        <div class="comments_section">
                                          {{-- <h3 id="comments_coun">{{count($complaint['complaint_comments'])}} Comments</h3> --}}
                                          @foreach($complaint['complaint_comments'] as $comments)
                                              <div class="media">
                                                  <div class="media-body">
                                                      <h5 class="media-heading"><a href="mailto:{{$comments['email']}}">
                                                        {{  substr($comments['email'], 0 , 5)  }}...
                                                      </a></h5>
                                                      <p class="p_comment">{{$comments['comment']}}</p>
                                                      <ul class="list-unstyled list-inline media-detail pull-left">
                                                          <li><i class="fa fa-calendar"></i>{{$comments['created_at']}}</li>
                                                      </ul>
                                                  </div>
                                              </div>
                                              @endforeach
                                        </div>
                                        <!-- COMMENT  - END -->
                                        
                                    
                                    </div>
                                </div>
                            </div>
                        </section>

                  </div>
              </div>
          </div>
    </div>


  </div>

@endsection

@section('javascript')
<script type="text/javascript">

    $("#btn-save").click(function (e) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            }
        });
        e.preventDefault();
        var formData = {
            email: $('#email').val(),
            comment: $('#complaint_comment').val(),
            complaint_id: $('#complaint_id').val(),
        };
        var type = "POST";
        var ajaxurl = "{{route('complaint.add.comment')}}";

        $.ajax({
            type: type,
            url: ajaxurl,
            data: formData,
            dataType: 'json',
            success: function (data) {

              $('#email').val('');
              $('#complaint_comment').val('');

              var result = [];
              var comments = data;
              for (var i = 0; i < comments.length; i++) {

                result[i] = `<div class="media">
                                            <div class="media-body">
                                                <h5 class="media-heading"><a href="mailto:`+comments[i]['email']+`">`+comments[i]['email'].substr(1, 5)+`...</a></h5>
                                                <p class="p_comment">`+comments[i]['comment']+`</p>
                                                <ul class="list-unstyled list-inline media-detail pull-left">
                                                    <li><i class="fa fa-calendar"></i>`+comments[i]['created_at']+`</li>
                                                </ul>
                                            </div>
                                        </div>`
              }

              $('.comments_section').empty();
              $('.comments_section').append(result);
              // $('#collapseComplaintComments').slideToggle( );
              
               $('#comment_Added').fadeIn('slow', function(){
                   $('#comment_Added').delay(3000).fadeOut(); 
                });

            },
            error: function (data) {
                console.log('Error:', data);
            }
        });

    });  
</script>
@endsection