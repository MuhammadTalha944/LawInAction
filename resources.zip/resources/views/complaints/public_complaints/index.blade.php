@extends('layouts.website.app')
@section('title', 'Complaints')
@section('content')

<style type="text/css">
    .background_gradient{
      /*background: linear-gradient(170deg, rgba(0,0,0,1) 32%, rgba(255,204,25,0.964005585144214) 72%); */
      background: linear-gradient(170deg, rgb(179, 168, 168) 32%, rgba(200, 179, 106, 0.96) 72%);
    }
</style>
<div class="jumbotron text-center">
  <h2>Public Complaints</h2>
</div>
  
<div class="container" style="margin-bottom: 2%;">

    <div class="row" style="margin-top: 2%;">
      @if(count($complaints) > 0)
        @foreach($complaints as $complaint)
          <div class="col-sm-4" style="margin-bottom: 1%;">
            <div class="card" style="box-shadow: 4px 7px #e1dede; border-radius: 5%;">
              <div class="card-body background_gradient" style="border-radius: 5%;">
                  <h3 style="">Complaint {{ ++$loop->index }}</h3>
                  <p style="">Complaint added By : <b>{{$complaint->name}}</b>
                    <br>
                    Gender : <b>{{$complaint->gender}}</b> from Country : <b>{{ $complaint->country }}</b></p>
                  <p style="">Complaint Related to :{{ $complaint->complaint_related_to }} <br> Category : {{ $complaint->vistim_accused }}</p>
                  <div style="text-align: right;">
                     <button type="button" class="btn btn-sm 
                                        @if($complaint->status->name == 'Initiated')
                                            btn-primary
                                        @elseif($complaint->status->name == 'Open')
                                            btn-primary
                                        @elseif($complaint->status->name == 'Under Proceesing')
                                            btn-success
                                        @elseif($complaint->status->name == 'Pending')
                                            btn-danger
                                        @elseif($complaint->status->name == 'Resolved')
                                            btn-success
                                        @elseif($complaint->status->name == 'Closed')
                                            btn-warning
                                        @endif  ">{{$complaint->status->name}}</button> 
                     <a href="{{route('complaint.detail', $complaint->complaint_number )}}" class="btn btn-sm btn-warning">Open <i class="fas fa-external-link-alt"></i></a>
                  </div>
              </div>
            </div>
          </div>
          @endforeach
          @else
          <div class="card" style="box-shadow: 4px 7px #e1dede;">
              <div class="card-body " style="text-align: center;">
                  <h3>No Complaints Found</h3>
              </div>
            </div>
          @endif
    </div>


</div>

{{-- </body>
</html> --}}

@endsection