@extends('layouts.website.app')
@section('title', 'Complaint Status')
@section('content')


<div class="jumbotron text-center" style="padding: 2% !important;">
  <h2>Public Complaints Status</h2>
</div>
  
<div class="container" style="margin-bottom: 2%;">
 {{--  <div class="row">
    <div class="col-md-12" style="text-align: right;">
      <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#complaint_Status_model">
        Check Status
      </button>

      <a href="{{route('complaint.create')}}" class="btn btn-success btn-sm" >Write Complaint</a>
    </div>
  </div> --}}
  <div class="row" style="margin-top: 2%;">
    @if(count($complaints) > 0 )
          @foreach($complaints as $complaint)
            <div class="col-sm-6 offset-sm-3">
              <div class="card" style="box-shadow: 4px 7px #e1dede; background: linear-gradient(170deg, rgb(179, 168, 168) 32%, rgba(200, 179, 106, 0.96) 72%);">
                <div class="card-body">
                    <h3>Complaint # <small>{{ $complaint->complaint_number}}</small></h3>
                    <p>Complaint added By : <b>{{$complaint->name}}</b>
                      <br>
                      Gender : <b>{{$complaint->gender}}</b> from <b>{{ $complaint->country }}</b></p>
                    <p>Complaint Related to :{{ $complaint->complaint_related_to }} <br> And added by : {{ $complaint->vistim_accused }}</p>
                    <p><b>Phone No : </b>{{$complaint->phone_number}}</p>
                    @if($complaint->country == 'India')
                      <p><b>State : </b>{{ $complaint->state->name }}</p>
                      <p><b>District : </b>{{ $complaint->district->name }}</p>
                      <p><b>Police Station : </b>{{ $complaint->police_station }}</p>
                      <p><b>Pin Code : </b>{{ $complaint->pin_code }}</p>
                      
                    @endif
                    
                    <div style="text-align: right;">
                       <button type="button" class="btn btn-sm btn-primary">Status : <b>{{$complaint->status->name}}</b></button> 
                       <a href="{{route('complaint.detail', $complaint->complaint_number )}}" class="btn btn-sm btn-warning">Open Complaint</a>
                    </div>
                </div>
              </div>
            </div>
            @endforeach
        @else
        <div class="col-sm-12">
              <div class="card" style="box-shadow: 4px 7px #e1dede;text-align: center;">
                <h3>No Complaints Found, Search Again !!</h3>
              </div>
          </div>
        @endif
  </div>


</div>

@endsection